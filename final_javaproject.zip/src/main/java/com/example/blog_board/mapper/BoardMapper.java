package com.example.blog_board.mapper;

import com.example.blog_board.domain.Board;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface BoardMapper{

    int boardCount() throws Exception;

    List<Board> boardList() throws Exception;

    Board findById(Long boardId) throws Exception;

    Long save(Board board) throws Exception;

    Long update(Board board) throws Exception;

    void delete(Long boardId) throws Exception;

    int readCntUp(Long boardId) throws Exception;

}

package com.example.blog_board.controller;

import com.example.blog_board.domain.Board;
import com.example.blog_board.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class BoardController {

    @Autowired
    private final BoardService boardService;

    public BoardController(BoardService boardService) {

        this.boardService = boardService;
    }

    @GetMapping("/boards/hello")
    public ModelAndView Hello() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("/thymeleaf/hello");

        return mav;
    }

    @GetMapping("/boards/test")
    public ModelAndView test() throws Exception {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("/thymeleaf/hello");
        mav.addObject("cnt", boardService.boardCount());
        mav.addObject("test", boardService.boardList());

        return mav;
    }

    @GetMapping({"","/index.html"})
    public ModelAndView main() throws Exception {

        ModelAndView mav = new ModelAndView();
        mav.setViewName("/thymeleaf/boards");
        mav.addObject("boards", boardService.boardList());/* TODO board 리스트 조회 구현 */
        return mav;

    }

    @GetMapping("/boards/{boardId}")
    public ModelAndView board(@PathVariable Long boardId) throws Exception {
        ModelAndView mav = new ModelAndView();
        int countBoard = boardService.readCntUp(boardId);
        mav.addObject("readCnt", countBoard);

        Board board = boardService.findById(boardId);/* TODO board id로 board 조회 */
        mav.addObject("board", board);
        mav.setViewName("/thymeleaf/board");

        return mav;
    }

    @GetMapping("/boards/add")
    public String add(){

        return "/thymeleaf/addForm";
    }

    @PostMapping("/boards/add")
    public String add(@RequestParam String title, @RequestParam String content,
                      @RequestParam String name, RedirectAttributes redirectAttributes) throws Exception {

        Board newBoard = new Board(title, content, name);

        Long boardId = boardService.add(newBoard);/* TODO board 객체 생성하여 board 추가 */

        redirectAttributes.addAttribute("boardId", boardId);
        redirectAttributes.addAttribute("status", true);

        return "redirect:/";

    }

    @GetMapping("/boards/{boardId}/edit")
    public String editForm(@PathVariable Long boardId, Model model) throws Exception {
        Board findBoard = boardService.findById(boardId);/* TODO 수정 작업 전에 board id로 기존 board 조회 */
        model.addAttribute("board", findBoard);

        return "/thymeleaf/editForm";
    }

    @PostMapping("/boards/{boardId}/edit")
    public String editForm(@PathVariable Long boardId, @RequestParam String title,
                                 @RequestParam String content, @RequestParam String name) throws Exception {

        Board findBoard = boardService.findById(boardId);/* TODO 수정 작업 전에 board id로 기존 board 조회 */

        findBoard.setTitle(title);
        findBoard.setContent(content);
        findBoard.setName(name);

        boardService.update(findBoard);
        return "redirect:/";

    }

    @GetMapping("/boards/{boardId}/delete")
    public ModelAndView deleteBoard(@PathVariable Long boardId) throws Exception {
        ModelAndView mav = new ModelAndView();
        boardService.deleteById(boardId);/* TODO board id에 해당하는 board 삭제 */

        mav.setViewName("redirect:/");
        return mav;
    }

}

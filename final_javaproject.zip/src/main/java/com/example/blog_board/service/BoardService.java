package com.example.blog_board.service;

import com.example.blog_board.domain.Board;

import java.util.List;

public interface BoardService {

    /* TODO */
    // BoardService를 implement 하여 BoardService 클래스 생성
    // BoardMapper를 참고

    int boardCount() throws Exception;

    List<Board> boardList() throws Exception;

    Board findById(Long boardId) throws Exception;

    Long add(Board board) throws Exception;

    void update(Board board) throws Exception;

    void deleteById(Long boardId) throws Exception;

    int readCntUp(Long boardId) throws Exception;

}

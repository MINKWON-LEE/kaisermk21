package com.example.blog_board.aop;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import java.util.Arrays;

@Slf4j
@Aspect
@Component
public class LoggingAop {
    Logger logger = LoggerFactory.getLogger(LoggingAop.class);

    /* TODO
    point Cut과 Around를 사용하여 Controller의 각 API가 실행하는 시간을 로깅 출력
     */

    @Pointcut("execution(* com.example.blog_board.controller..*(..))")
    public void Controller(){}

    @Around("Controller()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {

        StopWatch stopWatch = new StopWatch();

        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        String methodName = signature.getMethod().getName();

        stopWatch.start();
        Object result = joinPoint.proceed();
        stopWatch.stop();

        long totalTimeMillis = stopWatch.getTotalTimeMillis();

        logger.info("Argument/Parameter : " + Arrays.toString(joinPoint.getArgs()));
        logger.info("실행 메서드: {}, 실행시간: {}ms", methodName, totalTimeMillis);
        return result;
    }

}

/* hint
    @Pointcut("execution(* com.example.blog_board.controller..*.*(..))")
    
    @Around("Controller()")
    public void around(ProceedingJoinPoint joinPoint) throws Throwable {
        StopWatch stopWatch = new StopWatch();
        joinPoint.proceed();
    }

 */


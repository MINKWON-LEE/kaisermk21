package com.example.blog_board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlogBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
